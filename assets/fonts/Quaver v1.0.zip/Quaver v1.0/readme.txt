On Windows:
Right click and "Install for All Users" to ensure font is accessible for some programs like Aseprite

Licensed under CC BY 3.0.
Free to use. Attribution not required, but appreciated. 
(don't resell this font or any modified derivatives and we're good)


Have fun!